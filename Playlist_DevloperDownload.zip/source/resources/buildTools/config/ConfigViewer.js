require(
	[
		"storymaps/playlist/core/Core"
	],
	function(Core){
		Core.init();
});